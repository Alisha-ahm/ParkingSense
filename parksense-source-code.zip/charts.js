/**
 * ParkSense - Charts Module
 * Custom HTML5 Canvas charts designed to match the reference dashboard aesthetic:
 * Smooth dual-tone royal-blue area wave curves, modern bar charts with rounded tops and value callouts,
 * and high-contrast blue/cyan donut distribution charts. Zero external dependencies.
 */

import { Storage } from './storage.js';

export const ChartRenderer = {
  /**
   * Prepares and scales a canvas for high-DPI displays.
   */
  setupCanvas(canvas) {
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const width = rect.width || canvas.width || 400;
    const height = rect.height || canvas.height || 220;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    return { ctx, width, height, dpr };
  },

  /**
   * 1. Hourly Occupancy Line / Area Chart (matches the wave mountain graph in image)
   */
  renderHourlyLineChart(canvasId, targetDayOfWeek = new Date().getDay()) {
    const canvas = document.getElementById(canvasId);
    const setup = this.setupCanvas(canvas);
    if (!setup) return;
    const { ctx, width, height } = setup;

    const history = Storage.getAnalyticsHistory();

    // 24 hours of data
    const dayRecords = history.filter((r) => r.dayOfWeek === targetDayOfWeek);
    const hourlyData = [];
    for (let h = 0; h < 24; h++) {
      const match = dayRecords.find((r) => r.hour === h);
      hourlyData.push({
        hour: h,
        rate: match ? match.occupancyRate : Math.round(20 + Math.sin(h / 3) * 35),
      });
    }

    const pad = { top: 20, right: 15, bottom: 25, left: 35 };
    const chartW = width - pad.left - pad.right;
    const chartH = height - pad.top - pad.bottom;

    ctx.clearRect(0, 0, width, height);

    // Grid lines & Y-axis labels (01, 02, 03, 04, 05)
    const ySteps = [0, 25, 50, 75, 100];
    const yLabels = ['00', '01', '02', '03', '04', '05'];
    ctx.font = '600 10px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';

    ySteps.forEach((step, idx) => {
      const y = pad.top + chartH - (step / 100) * chartH;
      ctx.strokeStyle = '#f1f5f9';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(width - pad.right, y);
      ctx.stroke();

      ctx.fillStyle = '#9ca3af';
      ctx.fillText(yLabels[idx] || `${step}%`, pad.left - 8, y);
    });

    // Compute coordinate points
    const points = hourlyData.map((d, i) => {
      const x = pad.left + (i / 23) * chartW;
      const y = pad.top + chartH - (d.rate / 100) * chartH;
      return { x, y, hour: d.hour, rate: d.rate };
    });

    // Helper: Draw smooth bezier curve through points
    function drawSpline(ctx, pts) {
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 0; i < pts.length - 1; i++) {
        const p0 = pts[i === 0 ? 0 : i - 1];
        const p1 = pts[i];
        const p2 = pts[i + 1];
        const p3 = pts[i + 2 < pts.length ? i + 2 : i + 1];

        const cp1x = p1.x + (p2.x - p0.x) / 6;
        const cp1y = p1.y + (p2.y - p0.y) / 6;
        const cp2x = p2.x - (p3.x - p1.x) / 6;
        const cp2y = p2.y - (p3.y - p1.y) / 6;

        ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y);
      }
    }

    // 1. Secondary wave layer (Sky blue, from reference image)
    const secondaryPoints = points.map((p, i) => ({
      x: p.x,
      y: p.y + Math.sin(i / 1.5) * 14 + 10,
    }));

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(secondaryPoints[0].x, pad.top + chartH);
    drawSpline(ctx, secondaryPoints);
    ctx.lineTo(secondaryPoints[secondaryPoints.length - 1].x, pad.top + chartH);
    ctx.closePath();
    ctx.fillStyle = 'rgba(90, 200, 250, 0.45)';
    ctx.fill();
    ctx.restore();

    // 2. Primary wave layer (Vibrant Royal Blue, from reference image)
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(points[0].x, pad.top + chartH);
    drawSpline(ctx, points);
    ctx.lineTo(points[points.length - 1].x, pad.top + chartH);
    ctx.closePath();
    const primaryGrad = ctx.createLinearGradient(0, pad.top, 0, pad.top + chartH);
    primaryGrad.addColorStop(0, '#0075ff');
    primaryGrad.addColorStop(1, '#0075ff');
    ctx.fillStyle = primaryGrad;
    ctx.fill();
    ctx.restore();

    // Line boundary stroke
    ctx.beginPath();
    drawSpline(ctx, points);
    ctx.strokeStyle = '#005fdb';
    ctx.lineWidth = 2;
    ctx.stroke();

    // X-axis numeric labels (00, 01, 02, 03, 04, 05 as shown in reference)
    ctx.font = '600 10px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillStyle = '#9ca3af';

    const xSampleIndices = [0, 5, 9, 14, 18, 23];
    const xLabels = ['00', '01', '02', '03', '04', '05'];
    xSampleIndices.forEach((idx, i) => {
      const p = points[idx];
      if (p) {
        ctx.fillText(xLabels[i] || '0' + i, p.x, pad.top + chartH + 8);
      }
    });
  },

  /**
   * 2. Daily Revenue Bar Chart with Floating Value Callout (matches reference image bar chart)
   */
  renderDailyRevenueBarChart(canvasId) {
    const canvas = document.getElementById(canvasId);
    const setup = this.setupCanvas(canvas);
    if (!setup) return;
    const { ctx, width, height } = setup;

    const history = Storage.getAnalyticsHistory();

    // Aggregate last 7 days
    const dayTotals = [];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    for (let d = 6; d >= 0; d--) {
      const records = history.filter((r) => r.dayOffset === d);
      const rev = records.reduce((sum, r) => sum + (r.revenue || 0), 0);
      const sample = records[0];
      const name = sample ? dayNames[sample.dayOfWeek] : `D-${d}`;
      dayTotals.push({
        dayName: name,
        isToday: d === 0,
        revenue: Math.round(rev),
      });
    }

    const pad = { top: 35, right: 15, bottom: 25, left: 35 };
    const chartW = width - pad.left - pad.right;
    const chartH = height - pad.top - pad.bottom;

    ctx.clearRect(0, 0, width, height);

    const maxRev = Math.max(100, ...dayTotals.map((d) => d.revenue)) * 1.25;
    const stepX = chartW / dayTotals.length;
    const barWidth = Math.min(22, stepX * 0.45);

    // Y Grid lines
    const ySteps = [0, 25, 50, 75, 100];
    ctx.font = '600 10px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';

    ySteps.forEach((step) => {
      const y = pad.top + chartH - (step / 100) * chartH;
      ctx.strokeStyle = '#f1f5f9';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(width - pad.right, y);
      ctx.stroke();

      ctx.fillStyle = '#9ca3af';
      ctx.fillText(`${step}`, pad.left - 6, y);
    });

    let maxBarInfo = null;

    // Draw stacked-look vertical bars
    dayTotals.forEach((item, idx) => {
      const x = pad.left + idx * stepX + (stepX - barWidth) / 2;
      const fullH = chartH;
      const fillH = (item.revenue / maxRev) * chartH;

      // 1. Light background column pillar
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.roundRect(x, pad.top, barWidth, fullH, 4);
      ctx.fill();

      // 2. Active royal blue filled section
      ctx.fillStyle = '#0075ff';
      ctx.beginPath();
      ctx.roundRect(x, pad.top + fullH - fillH, barWidth, fillH, 4);
      ctx.fill();

      // Track highest bar for floating callout badge
      if (!maxBarInfo || item.revenue > maxBarInfo.revenue) {
        maxBarInfo = {
          x: x + barWidth / 2,
          y: pad.top + fullH - fillH,
          revenue: item.revenue,
        };
      }

      // X Day label
      ctx.fillStyle = '#64748b';
      ctx.font = '600 10px "Plus Jakarta Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(item.dayName, x + barWidth / 2, pad.top + chartH + 12);
    });

    // 3. Floating Blue Badge Callout (exact replica of the `220,342,123` badge in reference image)
    if (maxBarInfo) {
      const badgeW = 68;
      const badgeH = 22;
      const badgeX = Math.max(pad.left, Math.min(width - pad.right - badgeW, maxBarInfo.x - badgeW / 2));
      const badgeY = Math.max(10, maxBarInfo.y - badgeH - 6);

      ctx.fillStyle = '#0075ff';
      ctx.beginPath();
      ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 6);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = '700 10px "Plus Jakarta Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`$${maxBarInfo.revenue}`, badgeX + badgeW / 2, badgeY + badgeH / 2);
    }
  },

  /**
   * 3. Vehicle Type Donut / Pie Chart (matches pie chart in reference image with 25% / 60%)
   */
  renderVehicleTypeDonut(canvasId) {
    const canvas = document.getElementById(canvasId);
    const setup = this.setupCanvas(canvas);
    if (!setup) return;
    const { ctx, width, height } = setup;

    const tickets = Storage.getTickets();
    const history = Storage.getHistory();

    const counts = { car: 0, suv: 0, ev: 0, bike: 0 };
    tickets.forEach((t) => counts[t.type] ? counts[t.type]++ : (counts[t.type] = 1));
    history.slice(0, 30).forEach((h) => counts[h.type] ? counts[h.type]++ : (counts[h.type] = 1));

    const total = Object.values(counts).reduce((s, v) => s + v, 0) || 1;

    // Palette matching reference image: Royal Blue (#0075FF) & Sky Blue (#5AC8FA)
    const segments = [
      { type: 'Passenger Car', count: counts.car || 1, color: '#0075ff' },
      { type: 'SUV / Truck', count: counts.suv || 1, color: '#5ac8fa' },
      { type: 'EV Charging', count: counts.ev || 1, color: '#38bdf8' },
      { type: 'Motorcycle', count: counts.bike || 1, color: '#93c5fd' },
    ];

    ctx.clearRect(0, 0, width, height);

    const centerX = Math.min(width * 0.4, 110);
    const centerY = height / 2;
    const radius = Math.min(centerX - 10, centerY - 15, 68);

    let startAngle = -Math.PI / 2;

    segments.forEach((seg) => {
      const sliceAngle = (seg.count / total) * Math.PI * 2;
      const endAngle = startAngle + sliceAngle;

      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = seg.color;
      ctx.fill();

      // White slice separator
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      startAngle = endAngle;
    });

    // Percentage labels overlaid on major slices (25% and 60% like reference image)
    const carPercent = Math.round(((counts.car || 1) / total) * 100);
    const suvPercent = Math.round(((counts.suv || 1) / total) * 100);

    ctx.fillStyle = '#ffffff';
    ctx.font = '700 11px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${carPercent}%`, centerX + radius * 0.38, centerY + radius * 0.35);
    ctx.fillText(`${suvPercent}%`, centerX - radius * 0.45, centerY - radius * 0.15);

    // Legend on the Right Side
    const legendX = centerX + radius + 22;
    const itemH = 22;
    const legendStartY = centerY - (segments.length * itemH) / 2 + 4;

    segments.forEach((seg, i) => {
      const y = legendStartY + i * itemH;

      // Color pill swatch
      ctx.fillStyle = seg.color;
      ctx.beginPath();
      ctx.roundRect(legendX, y - 4, 10, 10, 2);
      ctx.fill();

      // Label
      ctx.textAlign = 'left';
      ctx.font = '600 11px "Plus Jakarta Sans", sans-serif';
      ctx.fillStyle = '#4b5563';
      ctx.fillText(seg.type, legendX + 16, y + 2);

      // Percentage
      const percent = Math.round((seg.count / total) * 100);
      ctx.textAlign = 'right';
      ctx.font = '700 10px "Plus Jakarta Sans", sans-serif';
      ctx.fillStyle = '#9ca3af';
      ctx.fillText(`${percent}%`, width - 15, y + 2);
    });
  },

  /**
   * 4. Peak-Hour Heatmap (Day of Week x Hour)
   */
  renderPeakHourHeatmap(canvasId) {
    const canvas = document.getElementById(canvasId);
    const setup = this.setupCanvas(canvas);
    if (!setup) return;
    const { ctx, width, height } = setup;

    const history = Storage.getAnalyticsHistory();

    const dayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const hours = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22];

    const pad = { top: 22, right: 12, bottom: 15, left: 35 };
    const chartW = width - pad.left - pad.right;
    const chartH = height - pad.top - pad.bottom;

    const cellW = chartW / hours.length;
    const cellH = chartH / dayLabels.length;

    ctx.clearRect(0, 0, width, height);

    // Color gradient based on royal-blue aesthetic
    function getCellColor(rate) {
      if (rate >= 85) return '#ef4444'; // Red peak
      if (rate >= 70) return '#f59e0b'; // Amber high
      if (rate >= 50) return '#0075ff'; // Vibrant royal blue
      if (rate >= 30) return '#7dd3fc'; // Sky blue
      return '#e2e8f0'; // Soft gray
    }

    // Top Hour labels
    ctx.font = '600 9px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    ctx.fillStyle = '#9ca3af';

    hours.forEach((h, col) => {
      const x = pad.left + col * cellW + cellW / 2;
      const label = h < 12 ? `${h}A` : h === 12 ? '12P' : `${h - 12}P`;
      if (col % 2 === 0) {
        ctx.fillText(label, x, pad.top - 4);
      }
    });

    // Draw Grid
    dayLabels.forEach((dayName, row) => {
      const y = pad.top + row * cellH;

      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      ctx.font = '600 10px "Plus Jakarta Sans", sans-serif';
      ctx.fillStyle = '#64748b';
      ctx.fillText(dayName, pad.left - 6, y + cellH / 2);

      hours.forEach((h, col) => {
        const x = pad.left + col * cellW;
        const matching = history.filter((r) => r.dayOfWeek === row && r.hour === h);
        const avgRate =
          matching.length > 0
            ? Math.round(matching.reduce((acc, v) => acc + v.occupancyRate, 0) / matching.length)
            : 35;

        ctx.fillStyle = getCellColor(avgRate);
        const gap = 1.5;
        ctx.beginPath();
        ctx.roundRect(x + gap, y + gap, cellW - gap * 2, cellH - gap * 2, 2);
        ctx.fill();
      });
    });
  },

  /**
   * Refreshes all charts currently visible in the DOM.
   */
  refreshAll() {
    if (document.getElementById('hourlyChart')) {
      this.renderHourlyLineChart('hourlyChart');
    }
    if (document.getElementById('revenueChart')) {
      this.renderDailyRevenueBarChart('revenueChart');
    }
    if (document.getElementById('donutChart')) {
      this.renderVehicleTypeDonut('donutChart');
    }
    if (document.getElementById('heatmapChart')) {
      this.renderPeakHourHeatmap('heatmapChart');
    }
  },
};
